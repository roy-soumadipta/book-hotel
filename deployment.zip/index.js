exports.handler = async (evt) => {
   // hotel's booking process

   return var;
}

